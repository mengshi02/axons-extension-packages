var fe = Object.defineProperty;
var ue = (t, n, s) => n in t ? fe(t, n, { enumerable: !0, configurable: !0, writable: !0, value: s }) : t[n] = s;
var P = (t, n, s) => ue(t, typeof n != "symbol" ? n + "" : n, s);
import oe, { useState as x, useRef as E, useCallback as z, useEffect as M, useMemo as U } from "react";
import { Spinner as G, Badge as B, Modal as ye, Input as W, Divider as Z, Select as q, Button as w, ConfirmDialog as ge, ProgressBar as re, Card as ae, CardBody as ie } from "axons-plugin-ui";
var le = { exports: {} }, J = {};
/**
 * @license React
 * react-jsx-runtime.production.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var me = Symbol.for("react.transitional.element"), ve = Symbol.for("react.fragment");
function ce(t, n, s) {
  var o = null;
  if (s !== void 0 && (o = "" + s), n.key !== void 0 && (o = "" + n.key), "key" in n) {
    s = {};
    for (var r in n)
      r !== "key" && (s[r] = n[r]);
  } else s = n;
  return n = s.ref, {
    $$typeof: me,
    type: t,
    key: o,
    ref: n !== void 0 ? n : null,
    props: s
  };
}
J.Fragment = ve;
J.jsx = ce;
J.jsxs = ce;
le.exports = J;
var e = le.exports;
const ee = 1e4, je = 6e4, be = 2;
function we({ pluginApi: t }) {
  const [n, s] = x("checking"), [o, r] = x(!1), [l, a] = x(!1), [i, d] = x(null), [f, m] = x(0), p = E(null), y = E(0), c = E(!0), h = E(!0), v = E(t);
  v.current = t;
  const j = E(async () => {
  }), k = z(async () => {
    var F;
    if (!c.current) return;
    h.current && s("checking");
    let b = !1, g = !1, S = 0;
    try {
      const I = await (await v.current.fetch("/api/engine/status")).json();
      (F = I.engine) != null && F.installed && (b = !0, g = !0, S = I.engine.running_count ?? 0);
    } catch {
      b = !1;
    }
    if (c.current)
      if (b)
        y.current = 0, s("healthy"), r(g), m(S), d(null), h.current = !1, p.current && clearTimeout(p.current), p.current = setTimeout(() => j.current(), ee);
      else {
        y.current += 1, (y.current >= be || h.current) && (s("unhealthy"), r(!1)), h.current = !1;
        const $ = Math.min(
          ee * Math.pow(2, y.current - 1),
          je
        );
        p.current && clearTimeout(p.current), p.current = setTimeout(() => j.current(), $);
      }
  }, []);
  j.current = k, M(() => (c.current = !0, j.current(), () => {
    c.current = !1, p.current && (clearTimeout(p.current), p.current = null);
  }), []);
  const L = z(async () => {
    if (!l) {
      a(!0), d(null);
      try {
        const b = await v.current.fetch("/api/engine/install", {
          method: "POST"
        });
        if (!b.ok) {
          let g = `HTTP ${b.status}`;
          try {
            const S = await b.json();
            g = (S == null ? void 0 : S.error) || g;
          } catch {
          }
          d(g);
        }
      } catch (b) {
        d((b == null ? void 0 : b.message) || "请求失败");
      } finally {
        y.current = 0, h.current = !0, a(!1), p.current && clearTimeout(p.current), p.current = setTimeout(() => j.current(), 0);
      }
    }
  }, [l]);
  return /* @__PURE__ */ e.jsxs(
    "div",
    {
      style: {
        display: "flex",
        alignItems: "center",
        gap: "8px",
        padding: "8px 12px",
        borderBottom: "1px solid var(--axons-border-subtle)",
        fontSize: "13px",
        color: "var(--axons-text-secondary)",
        flexWrap: "wrap"
      },
      children: [
        (n === "checking" || l) && /* @__PURE__ */ e.jsx(G, { size: "sm" }),
        /* @__PURE__ */ e.jsx("span", { children: "本地推理引擎: llama.cpp" }),
        /* @__PURE__ */ e.jsx(
          B,
          {
            variant: n === "healthy" ? "success" : n === "unhealthy" ? "error" : "warning",
            children: l ? "安装中…" : n === "healthy" ? "已就绪" : n === "unhealthy" ? "未安装" : "检查中"
          }
        ),
        n === "healthy" && f > 0 && /* @__PURE__ */ e.jsxs("span", { style: { opacity: 0.7 }, children: [
          f,
          " 个模型运行中"
        ] }),
        n === "unhealthy" && /* @__PURE__ */ e.jsxs("div", { style: { marginLeft: "auto", display: "flex", gap: 8, alignItems: "center" }, children: [
          /* @__PURE__ */ e.jsx(
            "button",
            {
              type: "button",
              disabled: l,
              onClick: L,
              style: {
                fontSize: 12,
                padding: "2px 10px",
                cursor: l ? "wait" : "pointer",
                background: "var(--axons-accent, #3b82f6)",
                color: "#fff",
                border: "none",
                borderRadius: 4,
                opacity: l ? 0.7 : 1
              },
              children: l ? "安装中…" : "安装 llama-server"
            }
          ),
          /* @__PURE__ */ e.jsx(
            "a",
            {
              href: "https://github.com/ggml-org/llama.cpp/releases",
              target: "_blank",
              rel: "noopener noreferrer",
              style: {
                color: "var(--axons-accent)",
                textDecoration: "none",
                fontSize: 12
              },
              children: "手动下载"
            }
          )
        ] }),
        i && /* @__PURE__ */ e.jsxs(
          "div",
          {
            style: {
              width: "100%",
              marginTop: 4,
              fontSize: 12,
              color: "var(--axons-text-error, #ef4444)"
            },
            children: [
              "安装失败：",
              i
            ]
          }
        )
      ]
    }
  );
}
function N(t) {
  if (t === 0) return "0 B";
  const n = ["B", "KB", "MB", "GB", "TB"], s = 1024, o = Math.floor(Math.log(t) / Math.log(s));
  return `${(t / Math.pow(s, o)).toFixed(1)} ${n[o]}`;
}
function Se(t) {
  return t >= 1e6 ? `${(t / 1e6).toFixed(1)}M` : t >= 1e3 ? `${(t / 1e3).toFixed(0)}K` : t.toString();
}
function Ce(t, n) {
  return `/api/models/download?repo_id=${encodeURIComponent(t)}&quantization=${encodeURIComponent(n)}`;
}
function H(t, n) {
  return `${t}:${n}`;
}
function O(t) {
  var r;
  const n = t.split(":"), s = ((r = n[0].split("/").pop()) == null ? void 0 : r.replace("-GGUF", "").replace("-gguf", "")) || t, o = n[1];
  if (!o) {
    const l = s.match(/[-](Q[2-8](?:_[01KS](?:_[SML])?)?|IQ[1-4](?:_[A-Z]+)?|F16|BF16|F32)$/i);
    return l ? `${s.slice(0, -l[0].length)} (${l[1].toUpperCase()})` : s;
  }
  return `${s} (${o})`;
}
const te = [
  { value: "", label: "默认 (f16)" },
  { value: "f16", label: "f16" },
  { value: "q8_0", label: "q8_0 (推荐)" },
  { value: "q4_0", label: "q4_0 (省显存)" }
], ze = [
  { value: "", label: "自动" },
  { value: "off", label: "关闭" },
  { value: "on", label: "开启" }
];
function ke({ isOpen: t, onClose: n, model: s, pluginApi: o, onRun: r }) {
  var X;
  const [l, a] = x(-1), [i, d] = x(4096), [f, m] = x(0), [p, y] = x(!1), [c, h] = x(""), [v, j] = x(""), [k, L] = x(""), [b, g] = x(!0), [S, F] = x(!1), [$, I] = x(!1), [_, R] = x(null), [A, V] = x(!1), [de, Q] = x(!1);
  M(() => {
    if (!t) return;
    let u = !1;
    return (async () => {
      try {
        const C = await o.fetch(
          `/api/models/defaults?model=${encodeURIComponent(s.name)}&family=${encodeURIComponent(s.family || "")}`
        );
        if (u) return;
        if (C.ok) {
          const T = await C.json(), D = T.defaults;
          F(T.metal_support), a(D.n_gpu_layers ?? (T.metal_support ? -1 : 0)), d(D.ctx_size ?? 4096), y(D.no_warmup ?? !1), h(D.flash_attn ?? ""), j(D.cache_type_k ?? ""), L(D.cache_type_v ?? "");
        }
      } catch {
        a(-1), d(4096), y(!1);
      } finally {
        u || Q(!0);
      }
    })(), () => {
      u = !0;
    };
  }, [t, s.name, s.family, o]), M(() => {
    t || (R(null), V(!1), Q(!1), I(!1));
  }, [t]);
  const xe = z(async () => {
    try {
      const u = await o.fetch(
        `/api/models/defaults?model=${encodeURIComponent(s.name)}&family=${encodeURIComponent(s.family || "")}`
      );
      if (u.ok) {
        const C = await u.json(), T = C.defaults;
        a(T.n_gpu_layers ?? (C.metal_support ? -1 : 0)), d(T.ctx_size ?? 4096), y(T.no_warmup ?? !1), h(T.flash_attn ?? ""), j(T.cache_type_k ?? ""), L(T.cache_type_v ?? "");
      }
    } catch {
    }
  }, [s.name, s.family, o]), pe = () => ({
    n_gpu_layers: l,
    ctx_size: i,
    threads: f > 0 ? f : void 0,
    no_warmup: p || void 0,
    flash_attn: c || void 0,
    cache_type_k: v || void 0,
    cache_type_v: k || void 0
  }), he = async () => {
    V(!0), R(null);
    const u = pe();
    if (b)
      try {
        await o.fetch("/api/models/config", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ model: s.name, config: u })
        });
      } catch {
      }
    try {
      const C = await o.fetch("/api/models/run", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: s.name, ...u })
      });
      if (C.ok)
        r(), n();
      else {
        const T = await C.json().catch(() => ({ error: `HTTP ${C.status}` }));
        R(T.error || `启动失败 (HTTP ${C.status})`);
      }
    } catch (C) {
      R((C == null ? void 0 : C.message) || "网络请求失败");
    } finally {
      V(!1);
    }
  }, Y = ((X = s.family) == null ? void 0 : X.toLowerCase().startsWith("qwen")) ?? !1;
  return /* @__PURE__ */ e.jsx(ye, { isOpen: t, onClose: n, size: "sm", overlayOpacity: "none", children: /* @__PURE__ */ e.jsxs("div", { style: { padding: "16px 20px" }, children: [
    /* @__PURE__ */ e.jsx("div", { style: { display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }, children: /* @__PURE__ */ e.jsx("span", { style: { fontWeight: 600, fontSize: "14px", color: "var(--axons-text-primary)" }, children: "启动配置" }) }),
    /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "6px", marginBottom: "12px" }, children: [
      /* @__PURE__ */ e.jsx("span", { style: { fontSize: "13px", color: "var(--axons-text-secondary)" }, children: O(s.name) }),
      S && /* @__PURE__ */ e.jsx(B, { variant: "success", children: "Metal GPU" }),
      Y && /* @__PURE__ */ e.jsx(B, { variant: "warning", children: "需CPU模式" })
    ] }),
    de ? /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
      /* @__PURE__ */ e.jsxs("div", { style: { marginBottom: "12px" }, children: [
        /* @__PURE__ */ e.jsxs("label", { style: { fontSize: "12px", color: "var(--axons-text-secondary)", display: "block", marginBottom: "4px" }, children: [
          "GPU 层数 ",
          /* @__PURE__ */ e.jsx("span", { style: { color: "var(--axons-text-muted)" }, children: "(-1=全部, 0=纯CPU)" })
        ] }),
        /* @__PURE__ */ e.jsx(
          W,
          {
            type: "number",
            value: l,
            onChange: (u) => a(parseInt(u.target.value) || 0),
            style: { width: "100px", fontSize: "12px" }
          }
        ),
        Y && /* @__PURE__ */ e.jsx("div", { style: { fontSize: "11px", color: "var(--axons-color-warning, #d97706)", marginTop: "2px" }, children: "Qwen 系列在 Metal GPU 上有 warmup 兼容性问题，推荐设为 0（纯CPU）" }),
        !S && l !== 0 && /* @__PURE__ */ e.jsx("div", { style: { fontSize: "11px", color: "var(--axons-error)", marginTop: "2px" }, children: "当前系统不支持 Metal，GPU offload 将无效" })
      ] }),
      /* @__PURE__ */ e.jsxs("div", { style: { marginBottom: "12px" }, children: [
        /* @__PURE__ */ e.jsx("label", { style: { fontSize: "12px", color: "var(--axons-text-secondary)", display: "block", marginBottom: "4px" }, children: "上下文长度" }),
        /* @__PURE__ */ e.jsx(
          W,
          {
            type: "number",
            value: i,
            onChange: (u) => d(parseInt(u.target.value) || 4096),
            style: { width: "100px", fontSize: "12px" }
          }
        ),
        /* @__PURE__ */ e.jsx("div", { style: { fontSize: "11px", color: "var(--axons-text-muted)", marginTop: "2px" }, children: "影响内存占用和推理能力，默认 4096" })
      ] }),
      /* @__PURE__ */ e.jsxs("div", { style: { marginBottom: "12px" }, children: [
        /* @__PURE__ */ e.jsxs("label", { style: { fontSize: "12px", color: "var(--axons-text-secondary)", display: "block", marginBottom: "4px" }, children: [
          "线程数 ",
          /* @__PURE__ */ e.jsx("span", { style: { color: "var(--axons-text-muted)" }, children: "(0=自动)" })
        ] }),
        /* @__PURE__ */ e.jsx(
          W,
          {
            type: "number",
            value: f,
            onChange: (u) => m(parseInt(u.target.value) || 0),
            style: { width: "100px", fontSize: "12px" }
          }
        )
      ] }),
      /* @__PURE__ */ e.jsxs("div", { style: { marginBottom: "12px" }, children: [
        /* @__PURE__ */ e.jsxs("label", { style: { display: "flex", alignItems: "center", gap: "6px", fontSize: "12px", color: "var(--axons-text-secondary)", cursor: "pointer" }, children: [
          /* @__PURE__ */ e.jsx(
            "input",
            {
              type: "checkbox",
              checked: p,
              onChange: (u) => y(u.target.checked),
              style: { width: "auto" }
            }
          ),
          "跳过预热 (--no-warmup)"
        ] }),
        /* @__PURE__ */ e.jsx("div", { style: { fontSize: "11px", color: "var(--axons-text-muted)", marginTop: "2px", marginLeft: "20px" }, children: "部分模型在 Metal GPU warmup 时会崩溃" })
      ] }),
      /* @__PURE__ */ e.jsx(Z, {}),
      /* @__PURE__ */ e.jsxs(
        "button",
        {
          type: "button",
          onClick: () => I(!$),
          style: {
            background: "none",
            border: "none",
            cursor: "pointer",
            color: "var(--axons-text-secondary)",
            fontSize: "12px",
            padding: "8px 0",
            width: "100%",
            textAlign: "left",
            display: "flex",
            alignItems: "center",
            gap: "4px"
          },
          children: [
            /* @__PURE__ */ e.jsx(
              "svg",
              {
                width: "10",
                height: "10",
                viewBox: "0 0 10 10",
                style: { transform: $ ? "rotate(90deg)" : "rotate(0deg)", transition: "transform 0.15s" },
                fill: "currentColor",
                children: /* @__PURE__ */ e.jsx("path", { d: "M3 1l5 4-5 4z" })
              }
            ),
            "高级选项"
          ]
        }
      ),
      $ && /* @__PURE__ */ e.jsxs("div", { style: { marginTop: "8px" }, children: [
        /* @__PURE__ */ e.jsxs("div", { style: { marginBottom: "12px" }, children: [
          /* @__PURE__ */ e.jsx("label", { style: { fontSize: "12px", color: "var(--axons-text-secondary)", display: "block", marginBottom: "4px" }, children: "Flash Attention" }),
          /* @__PURE__ */ e.jsx(
            q,
            {
              value: c,
              onChange: (u) => h(u.target.value),
              style: { width: "120px", fontSize: "12px" },
              children: ze.map((u) => /* @__PURE__ */ e.jsx("option", { value: u.value, children: u.label }, u.value))
            }
          )
        ] }),
        /* @__PURE__ */ e.jsxs("div", { style: { marginBottom: "12px" }, children: [
          /* @__PURE__ */ e.jsx("label", { style: { fontSize: "12px", color: "var(--axons-text-secondary)", display: "block", marginBottom: "4px" }, children: "KV Cache K 量化" }),
          /* @__PURE__ */ e.jsx(
            q,
            {
              value: v,
              onChange: (u) => j(u.target.value),
              style: { width: "160px", fontSize: "12px" },
              children: te.map((u) => /* @__PURE__ */ e.jsx("option", { value: u.value, children: u.label }, u.value))
            }
          ),
          /* @__PURE__ */ e.jsx("div", { style: { fontSize: "11px", color: "var(--axons-text-muted)", marginTop: "2px" }, children: "量化 KV cache 节省显存" })
        ] }),
        /* @__PURE__ */ e.jsxs("div", { style: { marginBottom: "12px" }, children: [
          /* @__PURE__ */ e.jsx("label", { style: { fontSize: "12px", color: "var(--axons-text-secondary)", display: "block", marginBottom: "4px" }, children: "KV Cache V 量化" }),
          /* @__PURE__ */ e.jsx(
            q,
            {
              value: k,
              onChange: (u) => L(u.target.value),
              style: { width: "160px", fontSize: "12px" },
              children: te.map((u) => /* @__PURE__ */ e.jsx("option", { value: u.value, children: u.label }, u.value))
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ e.jsx(Z, {}),
      /* @__PURE__ */ e.jsx("div", { style: { marginBottom: "12px" }, children: /* @__PURE__ */ e.jsxs("label", { style: { display: "flex", alignItems: "center", gap: "6px", fontSize: "12px", color: "var(--axons-text-secondary)", cursor: "pointer" }, children: [
        /* @__PURE__ */ e.jsx(
          "input",
          {
            type: "checkbox",
            checked: b,
            onChange: (u) => g(u.target.checked),
            style: { width: "auto" }
          }
        ),
        "记住此模型的配置"
      ] }) }),
      _ && /* @__PURE__ */ e.jsx("div", { style: {
        marginBottom: "12px",
        padding: "8px 12px",
        background: "var(--axons-error-bg, #fef2f2)",
        border: "1px solid var(--axons-error, #ef4444)",
        borderRadius: "4px",
        fontSize: "12px",
        color: "var(--axons-error, #ef4444)",
        whiteSpace: "pre-wrap",
        maxHeight: "120px",
        overflow: "auto"
      }, children: _ }),
      /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", gap: "8px", justifyContent: "space-between", alignItems: "center" }, children: [
        /* @__PURE__ */ e.jsx(w, { variant: "ghost", size: "sm", onClick: xe, children: "使用推荐配置" }),
        /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", gap: "8px" }, children: [
          /* @__PURE__ */ e.jsx(w, { variant: "ghost", size: "sm", onClick: n, children: "取消" }),
          /* @__PURE__ */ e.jsx(w, { variant: "primary", size: "sm", onClick: he, disabled: A, children: A ? "启动中..." : "启动" })
        ] })
      ] })
    ] }) : /* @__PURE__ */ e.jsx("div", { style: { textAlign: "center", padding: "20px 0", color: "var(--axons-text-muted)", fontSize: "13px" }, children: "加载推荐配置..." })
  ] }) });
}
function _e({ model: t, pluginApi: n, onRefresh: s }) {
  const [o, r] = x(!1), [l, a] = x(!1), [i, d] = x(null), [f, m] = x(!1), [p, y] = x(""), [c, h] = x(!1), [v, j] = x(!1), k = async () => {
    var g, S, F, $;
    m(!0), h(!0);
    try {
      const _ = await (await n.fetch(`/api/models/logs?model=${encodeURIComponent(t.name)}&tail=100`)).json(), R = [];
      (S = (g = _.logs) == null ? void 0 : g.stderr) != null && S.length && R.push(`=== stderr ===
` + _.logs.stderr.join(`
`)), ($ = (F = _.logs) == null ? void 0 : F.stdout) != null && $.length && R.push(`=== stdout ===
` + _.logs.stdout.join(`
`)), _.process && R.push(`=== 进程状态 ===
PID: ${_.process.pid}
运行中: ${_.process.running}
退出码: ${_.process.exit_code ?? "N/A"}
端口: ${_.process.port}`), y(R.length ? R.join(`

`) : "(无日志)");
    } catch (I) {
      y(`获取日志失败: ${(I == null ? void 0 : I.message) || "未知错误"}`);
    } finally {
      h(!1);
    }
  }, L = async () => {
    r(!0), d(null);
    try {
      const g = await n.fetch("/api/models/stop", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: t.name })
      });
      if (g.ok)
        s();
      else {
        const S = await g.json().catch(() => ({ error: `HTTP ${g.status}` }));
        d(S.error || `停止失败 (HTTP ${g.status})`);
      }
    } catch (g) {
      d((g == null ? void 0 : g.message) || "网络请求失败");
    } finally {
      r(!1);
    }
  }, b = async () => {
    r(!0);
    try {
      await n.fetch("/api/models/delete", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: t.name })
      }), s();
    } catch (g) {
      console.error("Failed to delete model:", g);
    } finally {
      r(!1), a(!1);
    }
  };
  return /* @__PURE__ */ e.jsxs("div", { className: "plugin-chat-axons-huggingface__local-card", style: {
    padding: "12px 16px",
    borderBottom: "1px solid var(--axons-border-subtle)"
  }, children: [
    /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "4px" }, children: [
      /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "8px" }, children: [
        /* @__PURE__ */ e.jsx("span", { title: O(t.name), style: { fontWeight: 500, color: "var(--axons-text-primary)", fontSize: "14px", maxWidth: "120px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }, children: O(t.name) }),
        /* @__PURE__ */ e.jsx(B, { variant: t.running ? "success" : "default", children: t.running ? "运行中" : "已停止" })
      ] }),
      /* @__PURE__ */ e.jsx(
        "button",
        {
          onClick: k,
          disabled: o,
          title: "查看日志",
          style: {
            background: "none",
            border: "none",
            cursor: o ? "not-allowed" : "pointer",
            color: "var(--axons-text-muted)",
            fontSize: "16px",
            padding: "2px 4px",
            lineHeight: 1,
            display: "flex",
            alignItems: "center",
            opacity: o ? 0.5 : 1,
            transition: "color 0.15s"
          },
          onMouseEnter: (g) => g.currentTarget.style.color = "var(--axons-text-primary)",
          onMouseLeave: (g) => g.currentTarget.style.color = "var(--axons-text-muted)",
          children: /* @__PURE__ */ e.jsxs("svg", { width: "16", height: "16", viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round", children: [
            /* @__PURE__ */ e.jsx("path", { d: "M4 2h5.5L12 4.5V14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1z" }),
            /* @__PURE__ */ e.jsx("polyline", { points: "9.5,2 9.5,4.5 12,4.5" }),
            /* @__PURE__ */ e.jsx("line", { x1: "5", y1: "8", x2: "10", y2: "8" }),
            /* @__PURE__ */ e.jsx("line", { x1: "5", y1: "10.5", x2: "8", y2: "10.5" })
          ] })
        }
      )
    ] }),
    /* @__PURE__ */ e.jsxs("div", { style: {
      fontSize: "12px",
      color: "var(--axons-text-muted)",
      marginBottom: "8px"
    }, children: [
      t.parameter_size && /* @__PURE__ */ e.jsxs("span", { children: [
        t.parameter_size,
        " · "
      ] }),
      t.family && /* @__PURE__ */ e.jsxs("span", { children: [
        t.family,
        " · "
      ] }),
      /* @__PURE__ */ e.jsx("span", { children: N(t.size) })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", gap: "6px", justifyContent: "flex-end" }, children: [
      t.running ? /* @__PURE__ */ e.jsx(w, { variant: "ghost", size: "sm", onClick: L, disabled: o, children: o ? "..." : "停止" }) : /* @__PURE__ */ e.jsx(e.Fragment, { children: /* @__PURE__ */ e.jsx(w, { variant: "primary", size: "sm", onClick: () => j(!0), disabled: o, children: o ? "..." : "启动" }) }),
      /* @__PURE__ */ e.jsx(
        w,
        {
          variant: "secondary",
          size: "sm",
          onClick: () => a(!0),
          disabled: o,
          style: { color: "var(--axons-error)", borderColor: "var(--axons-error)" },
          children: o ? "..." : "清理"
        }
      )
    ] }),
    i && /* @__PURE__ */ e.jsx("div", { style: {
      marginTop: "8px",
      padding: "8px 12px",
      background: "var(--axons-error-bg, #fef2f2)",
      border: "1px solid var(--axons-error, #ef4444)",
      borderRadius: "4px",
      fontSize: "12px",
      color: "var(--axons-error, #ef4444)",
      whiteSpace: "pre-wrap",
      maxHeight: "120px",
      overflow: "auto"
    }, children: i }),
    /* @__PURE__ */ e.jsx(
      ge,
      {
        isOpen: l,
        title: "确认清理模型",
        message: `确认删除模型 ${O(t.name)}？此操作不可恢复。`,
        confirmLabel: "清理",
        cancelLabel: "取消",
        variant: "danger",
        onConfirm: b,
        onCancel: () => a(!1)
      }
    ),
    /* @__PURE__ */ e.jsx(
      ke,
      {
        isOpen: v,
        onClose: () => j(!1),
        model: t,
        pluginApi: n,
        onRun: s
      }
    ),
    f && /* @__PURE__ */ e.jsx("div", { style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: "rgba(0,0,0,0.5)",
      zIndex: 9999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }, onClick: () => m(!1), children: /* @__PURE__ */ e.jsxs("div", { style: {
      background: "var(--axons-bg-primary, #fff)",
      borderRadius: "8px",
      width: "80%",
      maxWidth: "700px",
      maxHeight: "80vh",
      display: "flex",
      flexDirection: "column",
      boxShadow: "0 4px 16px rgba(0,0,0,0.2)"
    }, onClick: (g) => g.stopPropagation(), children: [
      /* @__PURE__ */ e.jsxs("div", { style: {
        padding: "12px 16px",
        borderBottom: "1px solid var(--axons-border-subtle)",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center"
      }, children: [
        /* @__PURE__ */ e.jsxs("span", { style: { fontWeight: 500 }, children: [
          "模型日志 - ",
          O(t.name)
        ] }),
        /* @__PURE__ */ e.jsx(w, { variant: "ghost", size: "sm", onClick: () => m(!1), children: "关闭" })
      ] }),
      /* @__PURE__ */ e.jsx("div", { style: {
        padding: "12px 16px",
        flex: 1,
        overflow: "auto",
        fontFamily: "monospace",
        fontSize: "12px",
        whiteSpace: "pre-wrap",
        color: "var(--axons-text-primary)",
        background: "var(--axons-bg-secondary, #f9fafb)"
      }, children: c ? "加载中..." : p })
    ] }) })
  ] });
}
function Te({ pluginApi: t }) {
  const [n, s] = x([]), [o, r] = x(!0), l = z(async () => {
    try {
      const i = await (await t.fetch("/api/models/local")).json();
      s(i.models || []);
    } catch (a) {
      console.error("Failed to fetch local models:", a);
    } finally {
      r(!1);
    }
  }, [t]);
  return M(() => {
    l();
  }, [l]), o ? /* @__PURE__ */ e.jsx("div", { style: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "32px"
  }, children: /* @__PURE__ */ e.jsx(G, { size: "md" }) }) : n.length === 0 ? /* @__PURE__ */ e.jsxs("div", { style: {
    padding: "24px",
    textAlign: "center",
    color: "var(--axons-text-muted)",
    fontSize: "13px"
  }, children: [
    "暂无本地模型",
    /* @__PURE__ */ e.jsx("br", {}),
    /* @__PURE__ */ e.jsx("span", { style: { fontSize: "12px" }, children: "从 HuggingFace Tab 下载模型" })
  ] }) : /* @__PURE__ */ e.jsx("div", { children: n.map((a) => /* @__PURE__ */ e.jsx(
    _e,
    {
      model: a,
      pluginApi: t,
      onRefresh: l
    },
    a.name
  )) });
}
class Be {
  constructor(n) {
    P(this, "jobs", /* @__PURE__ */ new Map());
    P(this, "esMap", /* @__PURE__ */ new Map());
    P(this, "listeners", /* @__PURE__ */ new Set());
    P(this, "hydrated", !1);
    this.pluginApi = n;
  }
  subscribe(n) {
    return this.listeners.add(n), n(this.snapshot()), () => {
      this.listeners.delete(n);
    };
  }
  snapshot() {
    return Array.from(this.jobs.values()).sort((n, s) => s.startedAt - n.startedAt);
  }
  hasActive() {
    for (const n of this.jobs.values())
      if (n.status === "downloading") return !0;
    return !1;
  }
  activeCount() {
    let n = 0;
    for (const s of this.jobs.values())
      s.status === "downloading" && (n += 1);
    return n;
  }
  async hydrate() {
    if (!this.hydrated) {
      this.hydrated = !0;
      try {
        const s = await (await this.pluginApi.fetch("/api/models/download/status")).json();
        for (const o of s.jobs || []) {
          const r = H(o.repo_id, o.quantization), l = {
            key: r,
            repo_id: o.repo_id,
            quantization: o.quantization,
            status: o.status,
            progress: o.total > 0 ? o.completed / o.total : 0,
            completed: o.completed || 0,
            total: o.total || 0,
            detail: o.detail || "",
            error: o.error || null,
            startedAt: (o.started_at || Date.now() / 1e3) * 1e3
          };
          this.jobs.set(r, l), l.status === "downloading" && this.attachEventSource(o.repo_id, o.quantization);
        }
        this.emit();
      } catch {
        this.hydrated = !1;
      }
    }
  }
  start(n, s) {
    const o = H(n, s), r = this.jobs.get(o);
    if (r && r.status === "downloading") return;
    const l = {
      key: o,
      repo_id: n,
      quantization: s,
      status: "downloading",
      progress: 0,
      completed: 0,
      total: 0,
      detail: "准备下载...",
      error: null,
      startedAt: Date.now()
    };
    this.jobs.set(o, l), this.attachEventSource(n, s), this.emit();
  }
  async cancel(n, s) {
    const o = H(n, s), r = this.jobs.get(o);
    r && r.status === "downloading" && (r.status = "canceled", r.detail = "已取消", this.jobs.set(o, r));
    try {
      await this.pluginApi.fetch("/api/models/download/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ repo_id: n, quantization: s })
      });
    } catch {
    }
    this.closeEventSource(o), this.emit();
  }
  async retry(n, s) {
    const o = H(n, s), r = this.jobs.get(o);
    if (!(!r || r.status !== "error" && r.status !== "canceled")) {
      try {
        await this.pluginApi.fetch("/api/models/download/retry", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ repo_id: n, quantization: s })
        });
      } catch {
      }
      this.jobs.delete(o), this.closeEventSource(o), this.start(n, s);
    }
  }
  dismiss(n) {
    const s = this.jobs.get(n);
    !s || s.status === "downloading" || (this.jobs.delete(n), this.emit());
  }
  dismissAllFinished() {
    let n = !1;
    for (const [s, o] of this.jobs)
      o.status !== "downloading" && (this.jobs.delete(s), n = !0);
    n && this.emit();
  }
  attachEventSource(n, s) {
    const o = H(n, s);
    this.closeEventSource(o);
    const r = Ce(n, s), l = this.pluginApi.createEventSource(r);
    this.esMap.set(o, l), l.addEventListener("download_progress", (a) => {
      try {
        const i = JSON.parse(a.data);
        this.applyProgress(o, i);
      } catch {
      }
    }), l.addEventListener("download_complete", () => {
      const a = this.jobs.get(o);
      a && (a.status = "completed", a.progress = 1, a.detail = "下载完成", this.jobs.set(o, a)), this.closeEventSource(o), this.emit();
    }), l.addEventListener("download_error", (a) => {
      let i = "下载失败", d = !1;
      try {
        const m = JSON.parse(a.data);
        i = m.error || i, d = !!m.canceled;
      } catch {
      }
      const f = this.jobs.get(o);
      f && (f.status = d ? "canceled" : "error", f.error = i, f.detail = i, this.jobs.set(o, f)), this.closeEventSource(o), this.emit();
    }), l.onerror = () => {
      const a = this.jobs.get(o);
      a && a.status === "downloading" && (a.status = "error", a.error = "连接中断", a.detail = "连接中断", this.jobs.set(o, a), this.emit()), this.closeEventSource(o);
    };
  }
  applyProgress(n, s) {
    const o = this.jobs.get(n);
    o && (typeof s.total == "number" && s.total > 0 && (o.total = s.total), typeof s.completed == "number" && (o.completed = s.completed), o.total > 0 && (o.progress = Math.min(1, o.completed / o.total)), s.file && s.file_total ? o.detail = `下载文件 ${s.file_index}/${s.file_total}: ${s.file}` : o.detail = s.status || o.detail || "下载中...", this.jobs.set(n, o), this.emit());
  }
  closeEventSource(n) {
    const s = this.esMap.get(n);
    if (s) {
      try {
        s.close();
      } catch {
      }
      this.esMap.delete(n);
    }
  }
  emit() {
    const n = this.snapshot();
    for (const s of this.listeners)
      try {
        s(n);
      } catch {
      }
  }
}
const ne = /* @__PURE__ */ new Map();
function K(t) {
  const n = t.pluginId || "default";
  let s = ne.get(n);
  return s || (s = new Be(t), ne.set(n, s)), s;
}
function Me({ model: t, pluginApi: n, onDownloadComplete: s }) {
  var j;
  const o = U(() => K(n), [n]), [r, l] = x(
    t.available_quantizations[0] || ""
  ), a = r ? H(t.id, r) : "", [i, d] = x(null);
  M(() => {
    if (a)
      return o.subscribe((k) => {
        const L = k.find((b) => b.key === a);
        d(L || null);
      });
  }, [o, a]), M(() => {
    (i == null ? void 0 : i.status) === "completed" && s();
  }, [i == null ? void 0 : i.status, s]);
  const f = (i == null ? void 0 : i.status) === "downloading", m = (i == null ? void 0 : i.progress) ?? 0, p = (i == null ? void 0 : i.detail) ?? "", y = () => {
    r && o.start(t.id, r);
  }, c = () => {
    r && o.cancel(t.id, r);
  }, h = () => {
    r && o.retry(t.id, r);
  }, v = ((j = t.id.split("/").pop()) == null ? void 0 : j.replace("-GGUF", "").replace("-gguf", "")) || t.id;
  return /* @__PURE__ */ e.jsxs("div", { className: "plugin-chat-axons-huggingface__hf-card", style: {
    padding: "12px 16px",
    borderBottom: "1px solid var(--axons-border-subtle)"
  }, children: [
    /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "8px", marginBottom: "4px" }, children: [
      /* @__PURE__ */ e.jsx("span", { style: {
        fontWeight: 500,
        color: "var(--axons-text-primary)",
        fontSize: "14px"
      }, children: v }),
      t.pipeline_tag && /* @__PURE__ */ e.jsx(B, { variant: "info", children: t.pipeline_tag })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { style: {
      fontSize: "12px",
      color: "var(--axons-text-muted)",
      marginBottom: "8px"
    }, children: [
      t.author && /* @__PURE__ */ e.jsxs("span", { children: [
        t.author,
        " · "
      ] }),
      /* @__PURE__ */ e.jsxs("span", { children: [
        Se(t.downloads),
        " downloads"
      ] })
    ] }),
    t.available_quantizations.length > 0 && /* @__PURE__ */ e.jsx("div", { style: { display: "flex", gap: "4px", flexWrap: "wrap", marginBottom: "8px" }, children: t.available_quantizations.map((k) => /* @__PURE__ */ e.jsx(
      "button",
      {
        onClick: () => !f && l(k),
        className: `axons-badge ${k === r ? "axons-badge-info" : "axons-badge-default"}`,
        style: {
          cursor: f ? "not-allowed" : "pointer",
          border: "none",
          fontFamily: "var(--axons-font-sans)"
        },
        children: k
      },
      k
    )) }),
    t.available_quantizations.length === 0 && /* @__PURE__ */ e.jsx("div", { style: { fontSize: "12px", color: "var(--axons-text-muted)", marginBottom: "8px" }, children: "未检测到可用量化版本" }),
    f && /* @__PURE__ */ e.jsxs("div", { style: { marginBottom: "8px" }, children: [
      /* @__PURE__ */ e.jsx(re, { value: m }),
      /* @__PURE__ */ e.jsx("div", { style: {
        fontSize: "11px",
        color: "var(--axons-text-muted)",
        marginTop: "4px"
      }, children: p })
    ] }),
    i && i.status === "error" && /* @__PURE__ */ e.jsx("div", { style: { fontSize: "11px", color: "var(--axons-error, #ef4444)", marginBottom: "8px" }, children: i.error || "下载失败" }),
    i && i.status === "canceled" && /* @__PURE__ */ e.jsx("div", { style: { fontSize: "11px", color: "var(--axons-text-muted)", marginBottom: "8px" }, children: "已取消" }),
    /* @__PURE__ */ e.jsx("div", { style: { display: "flex", justifyContent: "flex-end", gap: "8px" }, children: f ? /* @__PURE__ */ e.jsx(
      w,
      {
        variant: "secondary",
        size: "sm",
        onClick: c,
        style: { color: "var(--axons-error)", borderColor: "var(--axons-error)" },
        children: "取消下载"
      }
    ) : i && (i.status === "error" || i.status === "canceled") ? /* @__PURE__ */ e.jsx(e.Fragment, { children: /* @__PURE__ */ e.jsx(w, { variant: "primary", size: "sm", onClick: h, children: "重新下载" }) }) : r && /* @__PURE__ */ e.jsxs(w, { variant: "primary", size: "sm", onClick: y, children: [
      "下载 ",
      r
    ] }) })
  ] });
}
function Ie({ pluginApi: t, onDownloadComplete: n }) {
  const [s, o] = x(""), [r, l] = x([]), [a, i] = x(!1), [d, f] = x(!1), m = z(async () => {
    i(!0);
    try {
      const h = await (await t.fetch(
        `/api/hf/models?keyword=${encodeURIComponent(s)}&limit=20`
      )).json();
      l(h.models || []), f(!0);
    } catch (c) {
      console.error("Failed to search HF models:", c);
    } finally {
      i(!1);
    }
  }, [t, s]), p = z(async () => {
    i(!0);
    try {
      const h = await (await t.fetch("/api/hf/models?sort=downloads&limit=20")).json();
      l(h.models || []), f(!0);
    } catch (c) {
      console.error("Failed to load popular models:", c);
    } finally {
      i(!1);
    }
  }, [t]);
  oe.useEffect(() => {
    p();
  }, [p]);
  const y = (c) => {
    c.key === "Enter" && m();
  };
  return /* @__PURE__ */ e.jsxs("div", { children: [
    /* @__PURE__ */ e.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      gap: "6px",
      padding: "8px 12px",
      borderBottom: "1px solid var(--axons-border-subtle)",
      boxSizing: "border-box"
    }, children: [
      /* @__PURE__ */ e.jsx(
        "input",
        {
          type: "text",
          value: s,
          onChange: (c) => o(c.target.value),
          onKeyDown: y,
          placeholder: "搜索 HuggingFace 模型...",
          style: {
            flex: 1,
            minWidth: 0,
            height: "28px",
            padding: "0 10px",
            borderRadius: "4px",
            border: "1px solid var(--axons-border-default)",
            background: "var(--axons-color-surface)",
            color: "var(--axons-text-primary)",
            fontSize: "12px",
            lineHeight: "16px",
            outline: "none",
            boxSizing: "border-box"
          }
        }
      ),
      /* @__PURE__ */ e.jsx(
        "button",
        {
          type: "button",
          onClick: m,
          disabled: a,
          style: {
            flexShrink: 0,
            height: "28px",
            padding: "0 12px",
            borderRadius: "4px",
            border: "1px solid var(--axons-accent)",
            background: "var(--axons-accent)",
            color: "#fff",
            fontSize: "12px",
            lineHeight: "16px",
            fontWeight: 500,
            cursor: a ? "not-allowed" : "pointer",
            opacity: a ? 0.6 : 1,
            outline: "none",
            boxSizing: "border-box",
            whiteSpace: "nowrap"
          },
          children: a ? "..." : "搜索"
        }
      )
    ] }),
    a && r.length === 0 ? /* @__PURE__ */ e.jsx("div", { style: {
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      padding: "32px"
    }, children: /* @__PURE__ */ e.jsx(G, { size: "md" }) }) : r.length === 0 && d ? /* @__PURE__ */ e.jsx("div", { style: {
      padding: "24px",
      textAlign: "center",
      color: "var(--axons-text-muted)",
      fontSize: "13px"
    }, children: "未找到匹配的模型" }) : /* @__PURE__ */ e.jsx("div", { children: r.map((c) => /* @__PURE__ */ e.jsx(
      Me,
      {
        model: c,
        pluginApi: t,
        onDownloadComplete: n
      },
      c.id
    )) })
  ] });
}
function Re({ pluginApi: t }) {
  const n = U(() => K(t), [t]), [s, o] = x([]), [r, l] = x(!1), a = E(null), i = E(null);
  M(() => n.subscribe(o), [n]), M(() => {
    if (!r) return;
    const h = (v) => {
      const j = v.target;
      a.current && !a.current.contains(j) && i.current && !i.current.contains(j) && l(!1);
    };
    return document.addEventListener("mousedown", h), () => document.removeEventListener("mousedown", h);
  }, [r]);
  const d = U(
    () => s.filter((h) => h.status === "downloading").length,
    [s]
  ), f = s.length > 0, m = z(
    (h) => {
      const v = s.find((j) => j.key === h);
      v && n.cancel(v.repo_id, v.quantization);
    },
    [n, s]
  ), p = z(
    (h) => {
      n.dismiss(h);
    },
    [n]
  ), y = z(() => {
    n.dismissAllFinished();
  }, [n]), c = z(
    (h) => {
      const v = s.find((j) => j.key === h);
      v && n.retry(v.repo_id, v.quantization);
    },
    [n, s]
  );
  return f ? /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsxs(
      "button",
      {
        ref: i,
        type: "button",
        onClick: () => l((h) => !h),
        "aria-label": "下载任务列表",
        style: {
          position: "relative",
          background: "none",
          border: "none",
          cursor: "pointer",
          padding: "2px 6px",
          display: "flex",
          alignItems: "center",
          gap: "4px",
          color: "var(--axons-text-secondary)",
          lineHeight: 1
        },
        children: [
          /* @__PURE__ */ e.jsxs(
            "svg",
            {
              width: "16",
              height: "16",
              viewBox: "0 0 16 16",
              fill: "none",
              stroke: "currentColor",
              strokeWidth: "1.5",
              strokeLinecap: "round",
              strokeLinejoin: "round",
              children: [
                /* @__PURE__ */ e.jsx("path", { d: "M8 2v9M4 8l4 4 4-4" }),
                /* @__PURE__ */ e.jsx("path", { d: "M2 13h12" })
              ]
            }
          ),
          d > 0 && /* @__PURE__ */ e.jsx(
            "span",
            {
              style: {
                position: "absolute",
                top: -4,
                right: 0,
                background: "var(--axons-accent, #3b82f6)",
                color: "#fff",
                fontSize: "10px",
                fontWeight: 600,
                minWidth: 16,
                height: 16,
                borderRadius: 8,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: "0 3px",
                lineHeight: 1
              },
              children: d
            }
          )
        ]
      }
    ),
    r && /* @__PURE__ */ e.jsx(
      "div",
      {
        ref: a,
        style: {
          position: "absolute",
          top: "38px",
          right: "8px",
          width: "340px",
          maxHeight: "400px",
          zIndex: 50,
          boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
          borderRadius: "8px",
          overflow: "hidden"
        },
        children: /* @__PURE__ */ e.jsx(ae, { children: /* @__PURE__ */ e.jsxs(ie, { children: [
          /* @__PURE__ */ e.jsxs(
            "div",
            {
              style: {
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                marginBottom: "8px"
              },
              children: [
                /* @__PURE__ */ e.jsxs("span", { style: { fontWeight: 600, fontSize: "13px" }, children: [
                  "下载任务",
                  d > 0 && /* @__PURE__ */ e.jsx("span", { style: { marginLeft: 6 }, children: /* @__PURE__ */ e.jsx(B, { variant: "info", children: d }) })
                ] }),
                /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", gap: "8px", alignItems: "center" }, children: [
                  s.some((h) => h.status !== "downloading") && /* @__PURE__ */ e.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: y,
                      style: {
                        background: "none",
                        border: "none",
                        fontSize: "11px",
                        color: "var(--axons-accent)",
                        cursor: "pointer",
                        padding: 0
                      },
                      children: "清除已完成"
                    }
                  ),
                  /* @__PURE__ */ e.jsx(
                    "button",
                    {
                      type: "button",
                      onClick: () => l(!1),
                      style: {
                        background: "none",
                        border: "none",
                        fontSize: "14px",
                        color: "var(--axons-text-muted)",
                        cursor: "pointer",
                        padding: 0,
                        lineHeight: 1
                      },
                      "aria-label": "关闭",
                      children: "✕"
                    }
                  )
                ] })
              ]
            }
          ),
          /* @__PURE__ */ e.jsx(
            "div",
            {
              style: {
                maxHeight: "320px",
                overflowY: "auto",
                display: "flex",
                flexDirection: "column",
                gap: "8px"
              },
              children: s.map((h) => /* @__PURE__ */ e.jsx(
                Ee,
                {
                  job: h,
                  onCancel: m,
                  onRetry: c,
                  onDismiss: p
                },
                h.key
              ))
            }
          )
        ] }) })
      }
    )
  ] }) : null;
}
function Ee({ job: t, onCancel: n, onRetry: s, onDismiss: o }) {
  const r = O(H(t.repo_id, t.quantization)), l = t.status === "downloading", a = t.status === "completed", i = t.status === "error", d = t.status === "canceled", f = t.total > 0 ? `${N(t.completed)} / ${N(t.total)}` : t.completed > 0 ? `${N(t.completed)}` : "";
  return /* @__PURE__ */ e.jsxs(
    "div",
    {
      style: {
        padding: "8px",
        borderRadius: "6px",
        background: "var(--axons-color-surface-secondary, rgba(0,0,0,0.03))",
        fontSize: "12px"
      },
      children: [
        /* @__PURE__ */ e.jsxs(
          "div",
          {
            style: {
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              marginBottom: l ? "6px" : "4px"
            },
            children: [
              /* @__PURE__ */ e.jsx(
                "span",
                {
                  style: {
                    fontWeight: 500,
                    color: "var(--axons-text-primary)",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                    maxWidth: "200px"
                  },
                  title: t.key,
                  children: r
                }
              ),
              /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", gap: "4px", alignItems: "center" }, children: [
                a && /* @__PURE__ */ e.jsx(B, { variant: "success", children: "已完成" }),
                i && /* @__PURE__ */ e.jsx(B, { variant: "error", children: "失败" }),
                d && /* @__PURE__ */ e.jsx(B, { variant: "default", children: "已取消" }),
                l && n && /* @__PURE__ */ e.jsx(
                  w,
                  {
                    variant: "ghost",
                    size: "sm",
                    onClick: () => n(t.key),
                    style: { fontSize: "11px", color: "var(--axons-error)" },
                    children: "取消"
                  }
                ),
                (i || d) && s && /* @__PURE__ */ e.jsx(
                  w,
                  {
                    variant: "ghost",
                    size: "sm",
                    onClick: () => s(t.key),
                    style: { fontSize: "11px", color: "var(--axons-accent)" },
                    children: "重试"
                  }
                ),
                !l && /* @__PURE__ */ e.jsx(
                  w,
                  {
                    variant: "ghost",
                    size: "sm",
                    onClick: () => o(t.key),
                    style: { fontSize: "11px", color: "var(--axons-text-muted)" },
                    children: "关闭"
                  }
                )
              ] })
            ]
          }
        ),
        l && /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
          /* @__PURE__ */ e.jsx(re, { value: t.progress }),
          /* @__PURE__ */ e.jsxs(
            "div",
            {
              style: {
                display: "flex",
                justifyContent: "space-between",
                fontSize: "11px",
                color: "var(--axons-text-muted)",
                marginTop: "3px"
              },
              children: [
                /* @__PURE__ */ e.jsx("span", { children: t.progress > 0 ? `${(t.progress * 100).toFixed(1)}%` : t.detail }),
                f && /* @__PURE__ */ e.jsx("span", { children: f })
              ]
            }
          )
        ] }),
        i && t.error && /* @__PURE__ */ e.jsx(
          "div",
          {
            style: {
              fontSize: "11px",
              color: "var(--axons-error, #ef4444)",
              marginTop: "2px",
              overflow: "hidden",
              textOverflow: "ellipsis",
              whiteSpace: "nowrap"
            },
            title: t.error,
            children: t.error
          }
        ),
        (d || a) && /* @__PURE__ */ e.jsx(
          "div",
          {
            style: {
              fontSize: "11px",
              color: "var(--axons-text-muted)",
              marginTop: "2px"
            },
            children: d ? "已取消下载" : f || "下载完成"
          }
        )
      ]
    }
  );
}
function Le({ pluginApi: t, onDownloadComplete: n }) {
  const [s, o] = x([]), [r, l] = x(!0), a = oe.useMemo(() => K(t), [t]), i = z(async () => {
    try {
      const y = await (await t.fetch("/api/models/download/history")).json();
      o(y.history || []);
    } catch (p) {
      console.error("Failed to load download history:", p);
    } finally {
      l(!1);
    }
  }, [t]);
  M(() => {
    i();
  }, [i]);
  const d = z((p) => {
    a.start(p.repo_id, p.quantization);
  }, [a]), f = z(async (p) => {
    try {
      await t.fetch(`/api/models/download/history/${encodeURIComponent(p)}`, {
        method: "DELETE"
      }), o((y) => y.filter((c) => c.key !== p));
    } catch (y) {
      console.error("Failed to delete download history:", y);
    }
  }, [t]), m = (p) => {
    if (!p) return "-";
    try {
      return new Date(p).toLocaleString();
    } catch {
      return p;
    }
  };
  return r ? /* @__PURE__ */ e.jsx("div", { style: { display: "flex", justifyContent: "center", alignItems: "center", padding: "32px" }, children: /* @__PURE__ */ e.jsx(G, { size: "md" }) }) : s.length === 0 ? /* @__PURE__ */ e.jsx("div", { style: {
    padding: "24px",
    textAlign: "center",
    color: "var(--axons-text-muted)",
    fontSize: "13px"
  }, children: "暂无下载历史" }) : /* @__PURE__ */ e.jsx("div", { children: s.map((p) => /* @__PURE__ */ e.jsx(
    $e,
    {
      item: p,
      onRedownload: d,
      onDelete: f,
      formatTime: m
    },
    p.key
  )) });
}
function $e({ item: t, onRedownload: n, onDelete: s, formatTime: o }) {
  const r = O(t.key), l = t.status === "completed", a = t.status === "started", i = {
    available: "本地已有",
    partial: "部分下载",
    absent: "未下载"
  }[t.local_status] || t.local_status, d = {
    available: "success",
    partial: "info",
    absent: "default"
  }[t.local_status] || "default";
  return /* @__PURE__ */ e.jsxs("div", { style: {
    padding: "10px 16px",
    borderBottom: "1px solid var(--axons-border-subtle)"
  }, children: [
    /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "4px" }, children: [
      /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "6px", overflow: "hidden" }, children: [
        /* @__PURE__ */ e.jsx("span", { style: {
          fontWeight: 500,
          color: "var(--axons-text-primary)",
          fontSize: "13px",
          overflow: "hidden",
          textOverflow: "ellipsis",
          whiteSpace: "nowrap"
        }, title: t.key, children: r }),
        l && /* @__PURE__ */ e.jsx(B, { variant: "success", children: "完成" }),
        a && !l && /* @__PURE__ */ e.jsx(B, { variant: "default", children: "中断" })
      ] }),
      /* @__PURE__ */ e.jsx(B, { variant: d, children: i })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { style: {
      fontSize: "11px",
      color: "var(--axons-text-muted)",
      marginBottom: "6px",
      display: "flex",
      gap: "12px",
      flexWrap: "wrap"
    }, children: [
      t.total_size > 0 && /* @__PURE__ */ e.jsx("span", { children: N(t.total_size) }),
      /* @__PURE__ */ e.jsxs("span", { children: [
        "下载于 ",
        o(t.started_at)
      ] }),
      l && t.completed_at && /* @__PURE__ */ e.jsxs("span", { children: [
        "完成于 ",
        o(t.completed_at)
      ] })
    ] }),
    /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", justifyContent: "flex-end", gap: "8px" }, children: [
      t.local_status !== "available" && /* @__PURE__ */ e.jsx(
        w,
        {
          variant: "primary",
          size: "sm",
          onClick: () => n(t),
          children: t.local_status === "partial" ? "续传下载" : "重新下载"
        }
      ),
      /* @__PURE__ */ e.jsx(
        w,
        {
          variant: "ghost",
          size: "sm",
          onClick: () => s(t.key),
          style: { color: "var(--axons-text-muted)" },
          children: "删除记录"
        }
      )
    ] })
  ] });
}
const se = "hf_config";
function Fe({ pluginApi: t }) {
  const [n, s] = x(!1), [o, r] = x(""), [l, a] = x(""), [i, d] = x(!1), f = E(null), m = E(null);
  M(() => {
    (async () => {
      try {
        const c = await t.getState(se);
        c && typeof c == "object" && (r(c.hf_mirror || ""), a(c.hf_token || ""));
      } catch {
      }
    })();
  }, [t]), M(() => {
    if (!n) return;
    const c = (h) => {
      const v = h.target;
      f.current && !f.current.contains(v) && m.current && !m.current.contains(v) && s(!1);
    };
    return document.addEventListener("mousedown", c), () => document.removeEventListener("mousedown", c);
  }, [n]);
  const p = async () => {
    const c = {
      hf_mirror: o.trim().replace(/^https?:\/\//, "").replace(/\/+$/, ""),
      hf_token: l.trim()
    };
    try {
      await t.setState(se, c);
    } catch {
    }
    try {
      await t.fetch("/api/hf/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(c)
      });
    } catch {
    }
    r(c.hf_mirror), a(c.hf_token), d(!0), setTimeout(() => d(!1), 1500);
  }, y = () => {
    r(""), a("");
  };
  return /* @__PURE__ */ e.jsxs(e.Fragment, { children: [
    /* @__PURE__ */ e.jsx(
      "button",
      {
        ref: m,
        type: "button",
        onClick: () => s((c) => !c),
        "aria-label": "设置",
        title: "设置",
        style: {
          background: "none",
          border: "none",
          cursor: "pointer",
          padding: "2px 6px",
          display: "flex",
          alignItems: "center",
          color: "var(--axons-text-secondary)",
          lineHeight: 1
        },
        children: /* @__PURE__ */ e.jsxs(
          "svg",
          {
            width: "16",
            height: "16",
            viewBox: "0 0 16 16",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "1.2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            children: [
              /* @__PURE__ */ e.jsx("circle", { cx: "8", cy: "8", r: "2.5" }),
              /* @__PURE__ */ e.jsx("path", { d: "M8 1.5v1.5M8 13v1.5M1.5 8h1.5M13 8h1.5M3.4 3.4l1.1 1.1M11.5 11.5l1.1 1.1M3.4 12.6l1.1-1.1M11.5 4.5l1.1-1.1" })
            ]
          }
        )
      }
    ),
    n && /* @__PURE__ */ e.jsx(
      "div",
      {
        ref: f,
        style: {
          position: "absolute",
          top: "38px",
          right: "8px",
          width: "300px",
          zIndex: 50,
          boxShadow: "0 4px 16px rgba(0,0,0,0.12)",
          borderRadius: "8px",
          overflow: "hidden"
        },
        children: /* @__PURE__ */ e.jsx(ae, { children: /* @__PURE__ */ e.jsxs(ie, { children: [
          /* @__PURE__ */ e.jsxs("div", { style: {
            fontWeight: 600,
            fontSize: "13px",
            color: "var(--axons-text-primary)",
            marginBottom: "12px",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between"
          }, children: [
            /* @__PURE__ */ e.jsx("span", { children: "设置" }),
            /* @__PURE__ */ e.jsx(
              "button",
              {
                type: "button",
                onClick: () => s(!1),
                style: {
                  background: "none",
                  border: "none",
                  fontSize: "14px",
                  color: "var(--axons-text-muted)",
                  cursor: "pointer",
                  padding: 0,
                  lineHeight: 1
                },
                "aria-label": "关闭",
                children: "✕"
              }
            )
          ] }),
          /* @__PURE__ */ e.jsx("label", { style: {
            display: "block",
            fontSize: "12px",
            fontWeight: 500,
            color: "var(--axons-text-secondary)",
            marginBottom: "4px"
          }, children: "镜像站点" }),
          /* @__PURE__ */ e.jsx(
            W,
            {
              type: "text",
              value: o,
              onChange: (c) => r(c.target.value),
              placeholder: "hf-mirror.com",
              style: { fontSize: "12px", marginBottom: "4px" }
            }
          ),
          /* @__PURE__ */ e.jsx("div", { style: {
            fontSize: "11px",
            color: "var(--axons-text-muted)",
            marginBottom: "12px"
          }, children: "留空则使用默认 hf.co" }),
          /* @__PURE__ */ e.jsx("label", { style: {
            display: "block",
            fontSize: "12px",
            fontWeight: 500,
            color: "var(--axons-text-secondary)",
            marginBottom: "4px"
          }, children: "Access Token" }),
          /* @__PURE__ */ e.jsx(
            W,
            {
              type: "password",
              value: l,
              onChange: (c) => a(c.target.value),
              placeholder: "hf_xxxxxxxx",
              style: { fontSize: "12px", marginBottom: "4px" }
            }
          ),
          /* @__PURE__ */ e.jsx("div", { style: {
            fontSize: "11px",
            color: "var(--axons-text-muted)",
            marginBottom: "16px"
          }, children: "用于搜索 Gated 模型与解除限速" }),
          /* @__PURE__ */ e.jsxs("div", { style: {
            display: "flex",
            gap: "8px",
            justifyContent: "space-between",
            alignItems: "center"
          }, children: [
            /* @__PURE__ */ e.jsx(
              "button",
              {
                type: "button",
                onClick: y,
                style: {
                  background: "none",
                  border: "none",
                  fontSize: "12px",
                  color: "var(--axons-text-muted)",
                  cursor: "pointer",
                  padding: 0
                },
                children: "重置为默认"
              }
            ),
            /* @__PURE__ */ e.jsx(
              w,
              {
                variant: i ? "secondary" : "primary",
                size: "sm",
                onClick: p,
                children: i ? "已保存" : "保存"
              }
            )
          ] })
        ] }) })
      }
    )
  ] });
}
function Pe({ pluginApi: t }) {
  const [n, s] = x("local"), [o, r] = x(0), l = U(() => K(t), [t]);
  M(() => {
    l.hydrate();
  }, [l]);
  const a = z(() => {
    r((d) => d + 1);
  }, []), i = [
    { id: "local", label: "本地模型" },
    { id: "huggingface", label: "模型仓库" },
    { id: "history", label: "下载历史" }
  ];
  return /* @__PURE__ */ e.jsxs("div", { className: "plugin-chat-axons-huggingface__panel", style: {
    display: "flex",
    flexDirection: "column",
    height: "100%",
    background: "var(--axons-color-surface)",
    color: "var(--axons-text-primary)",
    fontFamily: "var(--axons-font-sans)",
    position: "relative"
  }, children: [
    /* @__PURE__ */ e.jsxs("div", { style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "8px 12px",
      height: "38px",
      boxSizing: "border-box",
      borderBottom: "1px solid var(--axons-border-subtle)",
      flexShrink: 0
    }, children: [
      /* @__PURE__ */ e.jsx("span", { style: { fontWeight: 600, fontSize: "14px", color: "var(--axons-text-primary)" }, children: "HuggingFace" }),
      /* @__PURE__ */ e.jsxs("div", { style: { display: "flex", alignItems: "center", gap: "4px" }, children: [
        /* @__PURE__ */ e.jsx(Fe, { pluginApi: t }),
        /* @__PURE__ */ e.jsx(Re, { pluginApi: t })
      ] })
    ] }),
    /* @__PURE__ */ e.jsx(
      "div",
      {
        style: {
          display: "flex",
          height: "31px",
          boxSizing: "border-box",
          borderBottom: "1px solid var(--axons-border-subtle)",
          flexShrink: 0
        },
        children: i.map((d) => {
          const f = d.id === n;
          return /* @__PURE__ */ e.jsx(
            "button",
            {
              type: "button",
              onClick: () => s(d.id),
              style: {
                flex: 1,
                padding: "0 16px",
                height: "100%",
                fontSize: "12px",
                lineHeight: "16px",
                fontWeight: 500,
                background: "transparent",
                border: "none",
                borderBottom: f ? "2px solid var(--axons-accent)" : "2px solid transparent",
                color: f ? "var(--axons-text-primary)" : "var(--axons-text-secondary)",
                cursor: "pointer",
                outline: "none",
                boxSizing: "border-box"
              },
              children: d.label
            },
            d.id
          );
        })
      }
    ),
    /* @__PURE__ */ e.jsx(we, { pluginApi: t }),
    /* @__PURE__ */ e.jsx("div", { style: { flex: 1, overflowY: "auto", minHeight: 0 }, children: n === "local" ? /* @__PURE__ */ e.jsx(Te, { pluginApi: t }, o) : n === "huggingface" ? /* @__PURE__ */ e.jsx(
      Ie,
      {
        pluginApi: t,
        onDownloadComplete: a
      }
    ) : /* @__PURE__ */ e.jsx(
      Le,
      {
        pluginApi: t,
        onDownloadComplete: a
      }
    ) })
  ] });
}
export {
  Pe as default
};
